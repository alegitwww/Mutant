﻿using MutantSelfHost.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MutantSelfHost
{
    public class Servico : IServico
    {
        public string Mensagem()
        {
            return "Conectando Self Host Mutant................";
        }

        #region Ingredientes 

        //Cadastrar Ingredientes
        public int CadastrarIngredientes(string IngredienteNome)
        {
            var db = new MutantFoodDb();
            return db.CadastrarIngredientesCD(IngredienteNome);
        }

        //Atualizar Ingredientes
        public int AtualizarIngredientes(int IngredienteId, string IngredienteNome)
        {
            var db = new MutantFoodDb();
            return db.AtualizarIngredientesCD(IngredienteId, IngredienteNome);
        }

        //Excluir Ingredientes
        public int ExcluirIngredientes(int ingredienteId)
        {
            var db = new MutantFoodDb();
            return db.ExcluirIngredientesCD(ingredienteId);
        }

        //Recupera Lista de Todos Ingredientes
        public List<Ingredientes> RecuperaListaTodosIngredientes()
        {
            var db = new MutantFoodDb();
            return db.RecuperaListaTodosIngredientesCodeCD();
        }

        //Recupera Lista de Todos Ingredientes Por Filtro
        public List<Ingredientes> RecuperaListaTodosIngredientesPorFiltro(string filtro)
        {
            var db = new MutantFoodDb();
            return db.RecuperaListaTodosIngredientesPorFiltroCD(filtro);
        }

        //Recupera Ingrediente Por Id
        public Ingredientes RecuperaIngredientePorId(int ingredienteId)
        {
            var db = new MutantFoodDb();
            return db.RecuperaIngredientePorIdCD(ingredienteId);
        }

        #endregion





        #region Precos

        // Cadastrar Preco
        public int CadastrarPreco(int precoIngredienteId, decimal precoValor)
        {
            var db = new MutantFoodDb();
            return db.CadastrarPrecoCD(precoIngredienteId, precoValor);
        }
        // Atualizar Preco
        public int AtualizarPreco(int precoId, decimal precoValor)
        {
            var db = new MutantFoodDb();
            return db.AtualizarPrecoCD(precoId, precoValor);
        }

        // Excluir Preco
        public int ExcluirPreco(int precoId)
        {
            var db = new MutantFoodDb();
            return db.ExcluirPrecoCD(precoId);
        }

        // Recupera Preco por Id
        public Precos RecuperaPrecoPorId(int precoId)
        {
            var db = new MutantFoodDb();
            return db.RecuperaPrecoPorIdCD(precoId);
        }

        // Recupera todos Precos
        public List<Precos> RecuperaListaTodosPrecos()
        {
            var db = new MutantFoodDb();
            return db.RecuperaListaTodosPrecosCD();
        }

        // Recupera todos Precos Por Filtro
        public List<Precos> RecuperaListaTodosPrecosPorFiltro(string filtro)
        {
            var db = new MutantFoodDb();
            return db.RecuperaListaTodosPrecosPorFiltroCD(filtro);
        }

        #endregion


        #region Cardapio

        //Cadastrar Cardapio
        public int CadastrarCardapio(string cardapioNome)
        {
            var db = new MutantFoodDb();
            return db.CadastrarCardapioCD(cardapioNome);
        }


        //Atualizar Cardapio
        public int AtualizarCardapio(int cardapioId, string cardapioNome)
        {
            var db = new MutantFoodDb();
            return db.AtualizarCardapioCD(cardapioId, cardapioNome);
        }

        //Excluir Cardapio
        public int ExcluirCardapio(int cardapioId)
        {
            var db = new MutantFoodDb();
            return db.ExcluirCardapioCD(cardapioId);
        }

        //Recupera um Cardapio por Id
        public Cardapios RecuperaCardapioPorId(int cardapioId)
        {
            var db = new MutantFoodDb();
            return db.RecuperaCardapioPorIdCD(cardapioId);
        }

        //Recupera lista de todos Cardapios
        public List<Cardapios> RecuperaListaTodosCardapios()
        {
            var db = new MutantFoodDb();
            return db.RecuperaListaTodosCardapiosCD();
        }

        //Recupera lista de todos Cardapios por Filtro
        public List<Cardapios> RecuperaListaTodosCardapiosPorFiltro(string filtro)
        {
            var db = new MutantFoodDb();
            return db.RecuperaListaTodosCardapiosPorFiltroCD(filtro);
        }

        #endregion


        #region Cardapio

        //Cadastrar CardapioIngredientes
        public int CadastrarCardapioIngredientes(int cardapioIngredientesCardapioId, int cardapioIngredientesIngredienteId)
        {
            var db = new MutantFoodDb();
            return db.CadastrarCardapioIngredientesCD(cardapioIngredientesCardapioId, cardapioIngredientesIngredienteId);
        }

        //Excluir CardapioIngredientes
        public int ExcluirCardapioIngredientes(int cardapioIngredientesId)
        {
            var db = new MutantFoodDb();
            return db.ExcluirCardapioIngredientesCD(cardapioIngredientesId);
        }

        //Recupera lista de todos Ingredientes do Cardapio
        public List<CardapioIngredientes> RecuperaListaTodosIngredientesCardapio()
        {
            var db = new MutantFoodDb();
            return db.RecuperaListaTodosIngredientesCardapioCD();
        }

        //Recupera lista de todos Ingredientes do Cardapio por Filtro
        public List<CardapioIngredientes> RecuperaListaTodosIngredientesCardapioPorFiltro(string filtro)
        {
            var db = new MutantFoodDb();
            return db.RecuperaListaTodosIngredientesCardapioPorFiltroCD(filtro);
        }

        #endregion


        #region Pedidos

        //Cadastrar Itens Pedido a Partir de Ingredientes do Cardapio -- @PedidoCardapioId
        public int CadastrarItensPedidoPartirIngredientesCardapio(int pedidoCardapioId)
        {
            var db = new MutantFoodDb();
            return db.CadastrarItensPedidoPartirIngredientesCardapioCD(pedidoCardapioId);
        }

        //Excluir Pedidos Por ID -- @PedidoId
        public int ExcluirPedidosPorID(int pedidoId)
        {
            var db = new MutantFoodDb();
            return db.ExcluirPedidosPorIDCD(pedidoId);
        }

        //Excluir Todos Pedidos
        public int ExcluirTodosPedidos()
        {
            var db = new MutantFoodDb();
            return db.ExcluirTodosPedidosCD();
        }

        //Cadastrar Itens Pedido a Partir de Ingredientes Selecionado -- @PedidoIngredienteId, @PedidoCardapioId, @PedidoCardapioNome, @PedidoQuantidade
        public int CadastrarItensPedidoPartirIngredientesSelecionado(int pedidoIngredienteId, int pedidoCardapioId, string pedidoCardapioNome, int pedidoQuantidade)
        {
            var db = new MutantFoodDb();
            return db.CadastrarItensPedidoPartirIngredientesSelecionadoCD(pedidoIngredienteId, pedidoCardapioId, pedidoCardapioNome, pedidoQuantidade);
        }

        //Recupera Todos Pedidos
        public List<Pedido> RecuperaTodosPedidos()
        {
            var db = new MutantFoodDb();
            return db.RecuperaTodosPedidosCD();
        }

        #endregion


        #region Transferencia

        //Recupera Transferencia
        public Transf RecuperaTransferencia()
        {
            var db = new MutantFoodDb();
            return db.RecuperaTransferenciaCD();
        }

        //Recupera Transferencia
        public Transf RecuperaTransferencia2()
        {
            var db = new MutantFoodDb();
            return db.RecuperaTransferencia2CD();
        }

        //Atualiza Transferencia
        public int AtualizaTransferencia(decimal transferenciaValor, decimal transferenciaValor2)
        {
            var db = new MutantFoodDb();
            return db.AtualizaTransferenciaCD(transferenciaValor, transferenciaValor2);
        }

        //Atualiza Transferencia
        public int AtualizaTransferencia2(decimal transferenciaValor, decimal transferenciaValor2)
        {
            var db = new MutantFoodDb();
            return db.AtualizaTransferencia2CD(transferenciaValor, transferenciaValor2);
        }

        #endregion
    }
}
