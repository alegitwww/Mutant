﻿using MutantSelfHost.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceModel;
using System.Text;
using System.Threading.Tasks;

namespace MutantSelfHost
{
    [ServiceContract]
    public interface IServico
    {
        [OperationContract]
        string Mensagem();

        #region Ingredientes

        //Cadastrar Ingredientes
        [OperationContract]
        int CadastrarIngredientes(string IngredienteNome);

        //Atualizar Ingredientes
        [OperationContract]
        int AtualizarIngredientes(int IngredienteId, string IngredienteNome);

        //Excluir Ingredientes
        [OperationContract]
        int ExcluirIngredientes(int IngredienteId);

        //Recupera Lista de Todos Ingredientes
        [OperationContract]
        List<Ingredientes> RecuperaListaTodosIngredientes();

        //Recupera Lista de Todos Ingredientes Por Filtro
        [OperationContract]
        List<Ingredientes> RecuperaListaTodosIngredientesPorFiltro(string filtro);

        //Recupera Ingrediente Por Id
        [OperationContract]
        Ingredientes RecuperaIngredientePorId(int ingredienteId);

        #endregion



        #region Precos

        // Cadastrar Preco 
        [OperationContract]
        int CadastrarPreco(int precoIngredienteId, decimal precoValor);

        // Atualizar Preco 
        [OperationContract]
        int AtualizarPreco(int precoId, decimal precoValor);

        // Excluir Preco
        [OperationContract]
        int ExcluirPreco(int precoId);

        // Recupera Preco por Id
        [OperationContract]
        Precos RecuperaPrecoPorId(int precoId);

        // Recupera todos Precos
        [OperationContract]
        List<Precos> RecuperaListaTodosPrecos();

        // Recupera todos Precos Por Filtro
        [OperationContract]
        List<Precos> RecuperaListaTodosPrecosPorFiltro(string filtro);
        #endregion



        #region Cardapio

        //Cadastrar Cardapio
        [OperationContract]
        int CadastrarCardapio(string cardapioNome);

        //Atualizar Cardapio
        [OperationContract]
        int AtualizarCardapio(int cardapioId, string cardapioNome);

        //Excluir Cardapio
        [OperationContract]
        int ExcluirCardapio(int cardapioId);

        //Recupera um Cardapio por Id
        [OperationContract]
        Cardapios RecuperaCardapioPorId(int cardapioId);

        //Recupera lista de todos Cardapios
        [OperationContract]
        List<Cardapios> RecuperaListaTodosCardapios();

        //Recupera lista de todos Cardapios por Filtro
        [OperationContract]
        List<Cardapios> RecuperaListaTodosCardapiosPorFiltro(string filtro);

        #endregion



        #region CardapioIngredientes

        //Cadastrar CardapioIngredientes
        [OperationContract]
        int CadastrarCardapioIngredientes(int cardapioIngredientesCardapioId, int cardapioIngredientesIngredienteId);

        //Excluir CardapioIngredientes
        [OperationContract]
        int ExcluirCardapioIngredientes(int cardapioIngredientesId);

        //Recupera lista de todos Ingredientes do Cardapio
        [OperationContract]
        List<CardapioIngredientes> RecuperaListaTodosIngredientesCardapio();

        //Recupera lista de todos Ingredientes do Cardapio por Filtro
        [OperationContract]
        List<CardapioIngredientes> RecuperaListaTodosIngredientesCardapioPorFiltro(string filtro);

        #endregion


        #region Pedidos

        //Cadastrar Itens Pedido a Partir de Ingredientes do Cardapio -- @PedidoCardapioId
        [OperationContract]
        int CadastrarItensPedidoPartirIngredientesCardapio(int pedidoCardapioId);

        //Excluir Pedidos Por ID -- @PedidoId
        [OperationContract]
        int ExcluirPedidosPorID(int pedidoId);

        //Excluir Todos Pedidos
        [OperationContract]
        int ExcluirTodosPedidos();

        //Cadastrar Itens Pedido a Partir de Ingredientes Selecionado -- @PedidoIngredienteId, @PedidoCardapioId, @PedidoCardapioNome, @PedidoQuantidade
        [OperationContract]
        int CadastrarItensPedidoPartirIngredientesSelecionado(int pedidoIngredienteId, int pedidoCardapioId, string pedidoCardapioNome, int pedidoQuantidade);

        //Recupera Todos Pedidos
        [OperationContract]
        List<Pedido> RecuperaTodosPedidos();

        #endregion


        #region Transferencia

        //Recupera Transferencia
        [OperationContract]
        Transf RecuperaTransferencia();

        //Recupera Transferencia 2
        [OperationContract]
        Transf RecuperaTransferencia2();

        //Atualiza Transferencia
        [OperationContract]
        int AtualizaTransferencia(decimal transferenciaValor, decimal transferenciaValor2);

        //Atualiza Transferencia 2
        [OperationContract]
        int AtualizaTransferencia2(decimal transferenciaValor, decimal transferenciaValor2);

        #endregion

    }
}
