﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MutantSelfHost.Models
{
    public class MutantFoodDb
    {

        #region Database-helper
        //  Retorna a string de conexao 
        private const string conexao = @"Data Source=LAPTOP-U6GKEOSN\SQLEXPRESS;Initial Catalog=MutantFood;Persist Security Info=True;User ID=sa;Password=xuip35";


        #region Ingredientes

        //Cadastrar Ingredientes
        public int CadastrarIngredientesCD(string IngredienteNome)
        {
            int tipo = 1; //determina tipo de operação da procedure
            int IngredienteId = 0;
            try
            {
                using (var cn = new SqlConnection(conexao))
                {
                    var cmd = new SqlCommand("Ingredientes_Crud", cn);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@Tipo", tipo);
                    cmd.Parameters.AddWithValue("@IngredienteNome", IngredienteNome);

                    cn.Open();

                    IngredienteId = Convert.ToInt32(cmd.ExecuteScalar());
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex);
            }
            return IngredienteId;
        }

        //Atualizar Ingredientes
        public int AtualizarIngredientesCD(int IngredienteId, string IngredienteNome)
        {
            int tipo = 2; //determina tipo de operação da procedure
            int resultado = 0;

            try
            {
                using (var cn = new SqlConnection(conexao))
                {
                    var cmd = new SqlCommand("Ingredientes_Crud", cn);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@Tipo", tipo);
                    cmd.Parameters.AddWithValue("@IngredienteId", IngredienteId);
                    cmd.Parameters.AddWithValue("@IngredienteNome", IngredienteNome);

                    cn.Open();

                    resultado = cmd.ExecuteNonQuery();
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex);
            }
            return resultado;
        }

        //Exclui Ingredientes
        public int ExcluirIngredientesCD(int ingredienteId)
        {
            int tipo = 3; //determina tipo de operação da procedure
            int retorno = 0;

            try
            {
                using (var cn = new SqlConnection(conexao))
                {
                    var cmd = new SqlCommand("Ingredientes_Crud", cn);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@Tipo", tipo);
                    cmd.Parameters.AddWithValue("@IngredienteId", ingredienteId);

                    cn.Open();
                    retorno = cmd.ExecuteNonQuery();
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex);
            }
            return retorno;
        }

        // Recupera lista de todos Ingredientes Ativos
        public List<Ingredientes> RecuperaListaTodosIngredientesCodeCD()
        {
            var lista = new List<Ingredientes>();
            int tipo = 4; //determina tipo de operação da procedure

            try
            {
                using (var cn = new SqlConnection(conexao))
                {
                    var cmd = new SqlCommand("Ingredientes_Crud", cn);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@Tipo", tipo);
                    cn.Open();

                    using (var dr = cmd.ExecuteReader())
                    {
                        while (dr.Read())
                        {
                            var ingredientes = new Ingredientes();
                            ingredientes.IngredienteId = Convert.ToInt32(dr["IngredienteId"]);
                            ingredientes.IngredienteNome = Convert.ToString(dr["IngredienteNome"]);
                            ingredientes.IngredienteAtivo = Convert.ToBoolean(dr["IngredienteAtivo"]);
                            ingredientes.IngredienteUsuario = Convert.ToString(dr["IngredienteUsuario"]);
                            ingredientes.IngredienteDataAlteracao = Convert.ToDateTime(dr["IngredienteDataAlteracao"]);

                            lista.Add(ingredientes);
                        }
                    }
                }
            }
            catch(Exception ex)
            {
                Console.WriteLine(ex);
            }
            return lista;
        }

        // Recupera lista de Ingredientes por Filtro
        public List<Ingredientes> RecuperaListaTodosIngredientesPorFiltroCD(string filtro)
        {
            var lista = new List<Ingredientes>();
            int tipo = 5; //determina tipo de operação da procedure

            try
            {
                using (var cn = new SqlConnection(conexao))
                {
                    var cmd = new SqlCommand("Ingredientes_Crud", cn);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@Tipo", tipo);
                    cmd.Parameters.AddWithValue("@Filtro", filtro);
                    cn.Open();

                    using (var dr = cmd.ExecuteReader())
                    {
                        while (dr.Read())
                        {
                            var ingredientes = new Ingredientes();
                            ingredientes.IngredienteId = Convert.ToInt32(dr["IngredienteId"]);
                            ingredientes.IngredienteNome = Convert.ToString(dr["IngredienteNome"]);
                            ingredientes.IngredienteAtivo = Convert.ToBoolean(dr["IngredienteAtivo"]);
                            ingredientes.IngredienteUsuario = Convert.ToString(dr["IngredienteUsuario"]);
                            ingredientes.IngredienteDataAlteracao = Convert.ToDateTime(dr["IngredienteDataAlteracao"]);

                            lista.Add(ingredientes);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex);
            }
            return lista;
        }

        //Recupera um Ingrediente por Id
        public Ingredientes RecuperaIngredientePorIdCD(int ingredienteId)
        {
            int tipo = 6; //determina tipo de operação da procedure
            Ingredientes ingredientes = null;

            using (var cn = new SqlConnection(conexao))
            {
                var cmd = new SqlCommand("Ingredientes_Crud", cn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@Tipo", tipo);
                cmd.Parameters.AddWithValue("@IngredienteId", ingredienteId);
                cn.Open();

                using (var dr = cmd.ExecuteReader())
                {
                    if (dr.Read())
                    {
                        ingredientes = new Ingredientes();
                        ingredientes.IngredienteId = Convert.ToInt32(dr["IngredienteId"]);
                        ingredientes.IngredienteNome = Convert.ToString(dr["IngredienteNome"]);
                        ingredientes.IngredienteAtivo = Convert.ToBoolean(dr["IngredienteAtivo"]);
                        ingredientes.IngredienteUsuario = Convert.ToString(dr["IngredienteUsuario"]);
                        ingredientes.IngredienteDataAlteracao = Convert.ToDateTime(dr["IngredienteDataAlteracao"]);
                    }
                }
            }
            return ingredientes;
        }

        #endregion

                
        #region Precos
        // Cadastrar Preco
        public int CadastrarPrecoCD(int PrecoIngredienteId, decimal PrecoValor)
        {
            int tipo = 1; //determina tipo de operação da procedure
            int PrecoId = 0;
            try
            {
                using (var cn = new SqlConnection(conexao))
                {
                    var cmd = new SqlCommand("Precos_Crud", cn);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@Tipo", tipo);
                    cmd.Parameters.AddWithValue("@PrecoIngredienteId", PrecoIngredienteId);
                    cmd.Parameters.AddWithValue("@PrecoValor", PrecoValor);

                    cn.Open();

                    PrecoId = Convert.ToInt32(cmd.ExecuteScalar());
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex);
            }
            return PrecoId;
        }

        // Atualizar Preco
        public int AtualizarPrecoCD(int PrecoId, decimal PrecoValor)
        {
            int tipo = 2; //determina tipo de operação da procedure
            int resultado = 0;

            try
            {
                using (var cn = new SqlConnection(conexao))
                {
                    var cmd = new SqlCommand("Precos_Crud", cn);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@Tipo", tipo);
                    cmd.Parameters.AddWithValue("@PrecoId", PrecoId);
                    cmd.Parameters.AddWithValue("@PrecoValor", PrecoValor);

                    cn.Open();

                    resultado = cmd.ExecuteNonQuery();
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex);
            }
            return resultado;
        }

        // Excluir Preco
        public int ExcluirPrecoCD(int PrecoId)
        {
            int tipo = 3; //determina tipo de operação da procedure
            int retorno = 0;

            try
            {
                using (var cn = new SqlConnection(conexao))
                {
                    var cmd = new SqlCommand("Precos_Crud", cn);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@Tipo", tipo);
                    cmd.Parameters.AddWithValue("@PrecoId", PrecoId);

                    cn.Open();
                    retorno = cmd.ExecuteNonQuery();
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex);
            }
            return retorno;
        }

        // Recupera Preco por Id
        public Precos RecuperaPrecoPorIdCD(int PrecoId)
        {
            int tipo = 4; //determina tipo de operação da procedure
            Precos preco = null;

            using (var cn = new SqlConnection(conexao))
            {
                var cmd = new SqlCommand("Precos_Crud", cn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@Tipo", tipo);
                cmd.Parameters.AddWithValue("@PrecoId", PrecoId);
                cn.Open();

                using (var dr = cmd.ExecuteReader())
                {
                    if (dr.Read())
                    {
                        preco = new Precos();
                        preco.PrecoId = Convert.ToInt32(dr["PrecoId"]);
                        preco.PrecoIngredienteId = Convert.ToInt32(dr["PrecoIngredienteId"]);
                        preco.PrecoValor = Convert.ToDecimal(dr["PrecoValor"]);
                        preco.PrecoAtivo = Convert.ToBoolean(dr["PrecoAtivo"]);
                        preco.PrecoUsuario = Convert.ToString(dr["PrecoUsuario"]);
                        preco.PrecoDataAlteracao = Convert.ToDateTime(dr["PrecoDataAlteracao"]);
                        preco.IngredienteNome = Convert.ToString(dr["IngredienteNome"]);
                    }
                }
            }
            return preco;
        }

        // Recupera todos Precos
        public List<Precos> RecuperaListaTodosPrecosCD()
        {
            var lista = new List<Precos>();
            int tipo = 5; //determina tipo de operação da procedure

            try
            {
                using (var cn = new SqlConnection(conexao))
                {
                    var cmd = new SqlCommand("Precos_Crud", cn);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@Tipo", tipo);
                    cn.Open();

                    using (var dr = cmd.ExecuteReader())
                    {
                        while (dr.Read())
                        {
                            var preco = new Precos();
                            preco = new Precos();
                            preco.PrecoId = Convert.ToInt32(dr["PrecoId"]);
                            preco.PrecoIngredienteId = Convert.ToInt32(dr["PrecoIngredienteId"]);
                            preco.PrecoValor = Convert.ToDecimal(dr["PrecoValor"]);
                            preco.PrecoAtivo = Convert.ToBoolean(dr["PrecoAtivo"]);
                            preco.PrecoUsuario = Convert.ToString(dr["PrecoUsuario"]);
                            preco.PrecoDataAlteracao = Convert.ToDateTime(dr["PrecoDataAlteracao"]);
                            preco.IngredienteNome = Convert.ToString(dr["IngredienteNome"]);

                            lista.Add(preco);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex);
            }
            return lista;
        }

        // Recupera todos Precos Por Filtro
        public List<Precos> RecuperaListaTodosPrecosPorFiltroCD(string filtro)
        {
            var lista = new List<Precos>();
            int tipo = 6; //determina tipo de operação da procedure

            try
            {
                using (var cn = new SqlConnection(conexao))
                {
                    var cmd = new SqlCommand("Precos_Crud", cn);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@Tipo", tipo);
                    cmd.Parameters.AddWithValue("@Filtro", filtro);
                    cn.Open();

                    using (var dr = cmd.ExecuteReader())
                    {
                        while (dr.Read())
                        {
                            var preco = new Precos();
                            preco = new Precos();
                            preco.PrecoId = Convert.ToInt32(dr["PrecoId"]);
                            preco.PrecoIngredienteId = Convert.ToInt32(dr["PrecoIngredienteId"]);
                            preco.PrecoValor = Convert.ToDecimal(dr["PrecoValor"]);
                            preco.PrecoAtivo = Convert.ToBoolean(dr["PrecoAtivo"]);
                            preco.PrecoUsuario = Convert.ToString(dr["PrecoUsuario"]);
                            preco.PrecoDataAlteracao = Convert.ToDateTime(dr["PrecoDataAlteracao"]);
                            preco.IngredienteNome = Convert.ToString(dr["IngredienteNome"]);

                            lista.Add(preco);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex);
            }
            return lista;
        }

        #endregion
        

        #region Cardapios


        //Cadastrar Cardapio
        public int CadastrarCardapioCD(string cardapioNome)
        {
            int tipo = 1; //determina tipo de operação da procedure
            int cardapioId = 0;
            try
            {
                using (var cn = new SqlConnection(conexao))
                {
                    var cmd = new SqlCommand("Cardapio_Crud", cn);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@Tipo", tipo);
                    cmd.Parameters.AddWithValue("@CardapioNome", cardapioNome);

                    cn.Open();

                    cardapioId = Convert.ToInt32(cmd.ExecuteScalar());
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex);
            }
            return cardapioId;
        }


        //Atualizar Cardapio
        public int AtualizarCardapioCD(int cardapioId, string cardapioNome)
        {
            int tipo = 2; //determina tipo de operação da procedure
            int resultado = 0;

            try
            {
                using (var cn = new SqlConnection(conexao))
                {
                    var cmd = new SqlCommand("Cardapio_Crud", cn);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@Tipo", tipo);
                    cmd.Parameters.AddWithValue("@CardapioId", cardapioId);
                    cmd.Parameters.AddWithValue("@CardapioNome", cardapioNome);

                    cn.Open();

                    resultado = cmd.ExecuteNonQuery();
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex);
            }
            return resultado;
        }

        //Excluir Cardapio
        public int ExcluirCardapioCD(int cardapioId)
        {
            int tipo = 3; //determina tipo de operação da procedure
            int retorno = 0;

            try
            {
                using (var cn = new SqlConnection(conexao))
                {
                    var cmd = new SqlCommand("Cardapio_Crud", cn);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@Tipo", tipo);
                    cmd.Parameters.AddWithValue("@CardapioId", cardapioId);

                    cn.Open();
                    retorno = cmd.ExecuteNonQuery();
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex);
            }
            return retorno;
        }

        //Recupera um Cardapio por Id
        public Cardapios RecuperaCardapioPorIdCD(int cardapioId)
        {
            int tipo = 6; //determina tipo de operação da procedure
            Cardapios cardapios = null;

            using (var cn = new SqlConnection(conexao))
            {
                var cmd = new SqlCommand("Cardapio_Crud", cn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@Tipo", tipo);
                cmd.Parameters.AddWithValue("@CardapioId", cardapioId);
                cn.Open();

                using (var dr = cmd.ExecuteReader())
                {
                    if (dr.Read())
                    {
                        cardapios = new Cardapios();
                        cardapios.CardapioId = Convert.ToInt32(dr["CardapioId"]);
                        cardapios.CardapioNome = Convert.ToString(dr["CardapioNome"]);
                        cardapios.CardapioAtivo = Convert.ToBoolean(dr["CardapioAtivo"]);
                        cardapios.CardapioUsuario = Convert.ToString(dr["CardapioUsuario"]);
                        cardapios.CardapioDataAlteracao = Convert.ToDateTime(dr["CardapioDataAlteracao"]);
                    }
                }
            }
            return cardapios;
        }

        //Recupera lista de todos Cardapios
        public List<Cardapios> RecuperaListaTodosCardapiosCD()
        {
            var lista = new List<Cardapios>();
            int tipo = 4; //determina tipo de operação da procedure

            try
            {
                using (var cn = new SqlConnection(conexao))
                {
                    var cmd = new SqlCommand("Cardapio_Crud", cn);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@Tipo", tipo);
                    cn.Open();

                    using (var dr = cmd.ExecuteReader())
                    {
                        while (dr.Read())
                        {
                            var cardapios = new Cardapios();
                            cardapios.CardapioId = Convert.ToInt32(dr["CardapioId"]);
                            cardapios.CardapioNome = Convert.ToString(dr["CardapioNome"]);
                            cardapios.CardapioAtivo = Convert.ToBoolean(dr["CardapioAtivo"]);
                            cardapios.CardapioUsuario = Convert.ToString(dr["CardapioUsuario"]);
                            cardapios.CardapioDataAlteracao = Convert.ToDateTime(dr["CardapioDataAlteracao"]);

                            lista.Add(cardapios);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex);
            }
            return lista;
        }

        //Recupera lista de todos Cardapios por Filtro
        public List<Cardapios> RecuperaListaTodosCardapiosPorFiltroCD(string filtro)
        {
            var lista = new List<Cardapios>();
            int tipo = 5; //determina tipo de operação da procedure

            try
            {
                using (var cn = new SqlConnection(conexao))
                {
                    var cmd = new SqlCommand("Cardapio_Crud", cn);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@Tipo", tipo);
                    cmd.Parameters.AddWithValue("@Filtro", filtro);
                    cn.Open();

                    using (var dr = cmd.ExecuteReader())
                    {
                        while (dr.Read())
                        {
                            var cardapios = new Cardapios();
                            cardapios.CardapioId = Convert.ToInt32(dr["CardapioId"]);
                            cardapios.CardapioNome = Convert.ToString(dr["CardapioNome"]);
                            cardapios.CardapioAtivo = Convert.ToBoolean(dr["CardapioAtivo"]);
                            cardapios.CardapioUsuario = Convert.ToString(dr["CardapioUsuario"]);
                            cardapios.CardapioDataAlteracao = Convert.ToDateTime(dr["CardapioDataAlteracao"]);

                            lista.Add(cardapios);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex);
            }
            return lista;
        }

        #endregion


        #region CardapioIngredientes

        //Cadastrar CardapioIngredientes
        public int CadastrarCardapioIngredientesCD(int cardapioIngredientesCardapioId, int cardapioIngredientesIngredienteId)
        {
            int tipo = 1; //determina tipo de operação da procedure
            int CardapioIngredientesId = 0;
            try
            {
                using (var cn = new SqlConnection(conexao))
                {
                    var cmd = new SqlCommand("CardapioIngredientes_Crud", cn);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@Tipo", tipo);
                    cmd.Parameters.AddWithValue("@CardapioIngredientesCardapioId", cardapioIngredientesCardapioId);
                    cmd.Parameters.AddWithValue("@CardapioIngredientesIngredienteId", cardapioIngredientesIngredienteId);

                    cn.Open();

                    CardapioIngredientesId = Convert.ToInt32(cmd.ExecuteScalar());
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex);
            }
            return CardapioIngredientesId;
        }

        //Excluir CardapioIngredientes
        public int ExcluirCardapioIngredientesCD(int cardapioIngredientesId)
        {
            int tipo = 3; //determina tipo de operação da procedure
            int retorno = 0;

            try
            {
                using (var cn = new SqlConnection(conexao))
                {
                    var cmd = new SqlCommand("CardapioIngredientes_Crud", cn);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@Tipo", tipo);
                    cmd.Parameters.AddWithValue("@CardapioIngredientesId", cardapioIngredientesId);

                    cn.Open();
                    retorno = cmd.ExecuteNonQuery();
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex);
            }
            return retorno;
        }

        //Recupera lista de todos Ingredientes do Cardapio
        public List<CardapioIngredientes> RecuperaListaTodosIngredientesCardapioCD()
        {
            var lista = new List<CardapioIngredientes>();
            int tipo = 4; //determina tipo de operação da procedure

            try
            {
                using (var cn = new SqlConnection(conexao))
                {
                    var cmd = new SqlCommand("CardapioIngredientes_Crud", cn);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@Tipo", tipo);
                    cn.Open();

                    using (var dr = cmd.ExecuteReader())
                    {
                        while (dr.Read())
                        {
                            var cardapioIngredientes = new CardapioIngredientes();
                            cardapioIngredientes.CardapioIngredientesId = Convert.ToInt32(dr["CardapioIngredientesId"]);
                            cardapioIngredientes.CardapioIngredientesCardapioId = Convert.ToInt32(dr["CardapioIngredientesCardapioId"]);
                            cardapioIngredientes.CardapioNome = Convert.ToString(dr["CardapioNome"]);
                            cardapioIngredientes.CardapioIngredientesIngredienteId = Convert.ToInt32(dr["CardapioIngredientesIngredienteId"]);
                            cardapioIngredientes.IngredienteNome = Convert.ToString(dr["IngredienteNome"]);
                            cardapioIngredientes.CardapioIngredientesUsuario = Convert.ToString(dr["CardapioIngredientesUsuario"]);
                            cardapioIngredientes.CardapioIngredientesDataAlteracao = Convert.ToDateTime(dr["CardapioIngredientesDataAlteracao"]);

                            lista.Add(cardapioIngredientes);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex);
            }
            return lista;
        }

        //Recupera lista de todos Ingredientes do Cardapio por Filtro
        public List<CardapioIngredientes> RecuperaListaTodosIngredientesCardapioPorFiltroCD(string filtro)
        {
            var lista = new List<CardapioIngredientes>();
            int tipo = 5; //determina tipo de operação da procedure

            try
            {
                using (var cn = new SqlConnection(conexao))
                {
                    var cmd = new SqlCommand("CardapioIngredientes_Crud", cn);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@Tipo", tipo);
                    cmd.Parameters.AddWithValue("@Filtro", filtro);
                    cn.Open();

                    using (var dr = cmd.ExecuteReader())
                    {
                        while (dr.Read())
                        {
                            var cardapioIngredientes = new CardapioIngredientes();
                            cardapioIngredientes.CardapioIngredientesId = Convert.ToInt32(dr["CardapioIngredientesId"]);
                            cardapioIngredientes.CardapioIngredientesCardapioId = Convert.ToInt32(dr["CardapioIngredientesCardapioId"]);
                            cardapioIngredientes.CardapioNome = Convert.ToString(dr["CardapioNome"]);
                            cardapioIngredientes.CardapioIngredientesIngredienteId = Convert.ToInt32(dr["CardapioIngredientesIngredienteId"]);
                            cardapioIngredientes.IngredienteNome = Convert.ToString(dr["IngredienteNome"]);
                            cardapioIngredientes.CardapioIngredientesUsuario = Convert.ToString(dr["CardapioIngredientesUsuario"]);
                            cardapioIngredientes.CardapioIngredientesDataAlteracao = Convert.ToDateTime(dr["CardapioIngredientesDataAlteracao"]);

                            lista.Add(cardapioIngredientes);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex);
            }
            return lista;
        }

        #endregion
        

        #region Pedidos

        //Cadastrar Itens Pedido a Partir de Ingredientes do Cardapio -- @PedidoCardapioId
        public int CadastrarItensPedidoPartirIngredientesCardapioCD(int pedidoCardapioId)
        {
            int tipo = 1; //determina tipo de operação da procedure
            int pedidosId = 0;
            try
            {
                using (var cn = new SqlConnection(conexao))
                {
                    var cmd = new SqlCommand("Pedidos_Crud", cn);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@Tipo", tipo);
                    cmd.Parameters.AddWithValue("@PedidoCardapioId", pedidoCardapioId);

                    cn.Open();

                    pedidosId = Convert.ToInt32(cmd.ExecuteScalar());
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex);
            }
            return pedidosId;
        }

        //Excluir Pedidos Por ID -- @PedidoId
        public int ExcluirPedidosPorIDCD(int pedidoId)
        {
            int tipo = 2; //determina tipo de operação da procedure
            int retorno = 0;

            try
            {
                using (var cn = new SqlConnection(conexao))
                {
                    var cmd = new SqlCommand("Pedidos_Crud", cn);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@Tipo", tipo);
                    cmd.Parameters.AddWithValue("@PedidoId", pedidoId);

                    cn.Open();
                    retorno = cmd.ExecuteNonQuery();
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex);
            }
            return retorno;
        }

        //Excluir Todos Pedidos
        public int ExcluirTodosPedidosCD()
        {
            int tipo = 3; //determina tipo de operação da procedure
            int retorno = 0;

            try
            {
                using (var cn = new SqlConnection(conexao))
                {
                    var cmd = new SqlCommand("Pedidos_Crud", cn);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@Tipo", tipo);
 
                    cn.Open();
                    retorno = cmd.ExecuteNonQuery();
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex);
            }
            return retorno;
        }

        //Cadastrar Itens Pedido a Partir de Ingredientes Selecionado -- @PedidoIngredienteId, @PedidoCardapioId, @PedidoCardapioNome, @PedidoQuantidade
        public int CadastrarItensPedidoPartirIngredientesSelecionadoCD(int pedidoIngredienteId, int pedidoCardapioId, string pedidoCardapioNome, int pedidoQuantidade)
        {
            int tipo = 4; //determina tipo de operação da procedure
            int pedidosId = 0;
            try
            {
                using (var cn = new SqlConnection(conexao))
                {
                    var cmd = new SqlCommand("Pedidos_Crud", cn);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@Tipo", tipo);
                    cmd.Parameters.AddWithValue("@PedidoIngredienteId", pedidoIngredienteId);
                    cmd.Parameters.AddWithValue("@PedidoCardapioId", pedidoCardapioId);
                    cmd.Parameters.AddWithValue("@PedidoCardapioNome", pedidoCardapioNome);
                    cmd.Parameters.AddWithValue("@PedidoQuantidade", pedidoQuantidade);

                    cn.Open();

                    pedidosId = Convert.ToInt32(cmd.ExecuteScalar());
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex);
            }
            return pedidosId;
        }

        //Recupera Todos Pedidos
        public List<Pedido> RecuperaTodosPedidosCD()
        {
            var lista = new List<Pedido>();
            int tipo = 5; //determina tipo de operação da procedure

            try
            {
                using (var cn = new SqlConnection(conexao))
                {
                    var cmd = new SqlCommand("Pedidos_Crud", cn);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@Tipo", tipo);
                    cn.Open();

                    using (var dr = cmd.ExecuteReader())
                    {
                        while (dr.Read())
                        {
                            var pedido = new Pedido();
 
                            pedido.PedidoId = Convert.ToInt32(dr["PedidoId"]);
                            pedido.PedidoNumero = Convert.ToInt32(dr["PedidoNumero"]);
                            pedido.PedidoCardapioId = Convert.ToInt32(dr["PedidoCardapioId"]);
                            pedido.PedidoCardapioNome = Convert.ToString(dr["PedidoCardapioNome"]);
                            pedido.PedidoIngredienteId = Convert.ToInt32(dr["PedidoIngredienteId"]);
                            pedido.PedidoIngredienteNome = Convert.ToString(dr["PedidoIngredienteNome"]);
                            pedido.PedidoPrecoValor = Convert.ToDecimal(dr["PedidoPrecoValor"]);
                            pedido.PedidoQuantidade = Convert.ToInt32(dr["PedidoQuantidade"]);
                            pedido.PedidoAtivo = Convert.ToBoolean(dr["PedidoAtivo"]);
                            pedido.PedidoUsuario = Convert.ToString(dr["PedidoUsuario"]);
                            pedido.PedidoDataAlteracao = Convert.ToDateTime(dr["PedidoDataAlteracao"]);

                            lista.Add(pedido);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex);
            }
            return lista;
        }

        #endregion



        #region Transferencia

        //Recupera Transferencia
        public Transf RecuperaTransferenciaCD()
        {
            Transf t = new Transf();
            int tipo = 1; //determina tipo de operação da procedure

            try
            {
                using (var cn = new SqlConnection(conexao))
                {
                    var cmd = new SqlCommand("Transferencia_Crud", cn);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@Tipo", tipo);
                    cn.Open();

                    using (var dr = cmd.ExecuteReader())
                    {
                        while (dr.Read())
                        {
                            t.TransferenciaValor  = Convert.ToDecimal(dr["TransferenciaValor"]);
                            t.TransferenciaValor2 = Convert.ToDecimal(dr["TransferenciaValor2"]);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex);
            }
            return t;
        }

        //Recupera Transferencia 2
        public Transf RecuperaTransferencia2CD()
        {
            Transf t = new Transf();
            int tipo = 2; //determina tipo de operação da procedure

            try
            {
                using (var cn = new SqlConnection(conexao))
                {
                    var cmd = new SqlCommand("Transferencia_Crud", cn);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@Tipo", tipo);
                    cn.Open();

                    using (var dr = cmd.ExecuteReader())
                    {
                        while (dr.Read())
                        {
                            t.TransferenciaValor = Convert.ToDecimal(dr["TransferenciaValor"]);
                            t.TransferenciaValor2 = Convert.ToDecimal(dr["TransferenciaValor2"]);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex);
            }
            return t;
        }

        //Atualiza Transferencia
        public int AtualizaTransferenciaCD(decimal transferenciaValor, decimal transferenciaValor2)
        {
            int tipo = 3; //determina tipo de operação da procedure
            int resultado = 0;

            try
            {
                using (var cn = new SqlConnection(conexao))
                {
                    var cmd = new SqlCommand("Transferencia_Crud", cn);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@Tipo", tipo);
                    cmd.Parameters.AddWithValue("@TransferenciaValor", transferenciaValor);
                    cmd.Parameters.AddWithValue("@TransferenciaValor2", transferenciaValor2);

                    cn.Open();

                    resultado = cmd.ExecuteNonQuery();
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex);
            }
            return resultado;
        }

        //Atualiza Transferencia
        public int AtualizaTransferencia2CD(decimal transferenciaValor, decimal transferenciaValor2)
        {
            int tipo = 4; //determina tipo de operação da procedure
            int resultado = 0;

            try
            {
                using (var cn = new SqlConnection(conexao))
                {
                    var cmd = new SqlCommand("Transferencia_Crud", cn);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@Tipo", tipo);
                    cmd.Parameters.AddWithValue("@TransferenciaValor", transferenciaValor);
                    cmd.Parameters.AddWithValue("@TransferenciaValor2", transferenciaValor2);

                    cn.Open();

                    resultado = cmd.ExecuteNonQuery();
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex);
            }
            return resultado;
        }

        #endregion

    }


    #endregion

}

