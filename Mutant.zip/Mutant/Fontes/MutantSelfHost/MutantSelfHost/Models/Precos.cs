﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;
using System.Web;

namespace MutantSelfHost.Models
{
    public class Precos
    {
        public int PrecoId { get; set; }
        public int PrecoIngredienteId { get; set; }
        public decimal PrecoValor { get; set; }
        public Boolean PrecoAtivo { get; set; }
        public string PrecoUsuario { get; set; }
        public DateTime PrecoDataAlteracao { get; set; }
        public string IngredienteNome { get; set; }
    }

}
