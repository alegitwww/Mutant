﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;
using System.Web;

namespace MutantSelfHost.Models
{
    public class CardapioIngredientes
    {
        public int CardapioIngredientesId { get; set; }
        public int CardapioIngredientesCardapioId { get; set; }
        public string CardapioNome { get; set; }
        public int CardapioIngredientesIngredienteId { get; set; }
        public string IngredienteNome { get; set; }
        public Boolean CardapioIngredientesAtivo { get; set; }
        public string CardapioIngredientesUsuario { get; set; }
        public DateTime CardapioIngredientesDataAlteracao { get; set; }
    }
}
