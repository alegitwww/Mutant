﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;
using System.Web;

namespace MutantSelfHost.Models
{
    public class Pedido
    {
        public int PedidoId { get; set; }
        public int PedidoNumero { get; set; }
        public int PedidoCardapioId { get; set; }
        public string PedidoCardapioNome { get; set; }
        public int PedidoIngredienteId { get; set; }
        public string PedidoIngredienteNome { get; set; }
        public decimal PedidoPrecoValor { get; set; }
        public int PedidoQuantidade { get; set; }
        public Boolean PedidoAtivo { get; set; }
        public string PedidoUsuario { get; set; }
        public DateTime PedidoDataAlteracao { get; set; }
    }
}
