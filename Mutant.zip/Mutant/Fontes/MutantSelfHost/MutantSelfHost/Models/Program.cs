﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ServiceModel.Description;
using System.ServiceModel;

namespace MutantSelfHost
{

    class Program
    {
        static void Main(string[] args)
        {
            //Define o endereço
            var url = new Uri("http://localhost:8989/Servico");

            //Cria um Host
            var host = new ServiceHost(typeof(Servico), url);

            //Adiciona um Behavior permitindo HttpGet (habilitando um protocolo)
            var smb = new ServiceMetadataBehavior();
            smb.HttpGetEnabled = true; //adiciona essa instancia dentro do host (comportamento do host) - habilita chamar serviço na URL do navegador   
            host.Description.Behaviors.Add(smb);

            //Inicia o serviço
            host.Open();
            Console.WriteLine("O serviço está no ar, no endereço:{0}", url);
            Console.WriteLine("Tecle ENTER para sair.");
            Console.ReadLine();

            // Fecha o serviço
            host.Close();
        }
    }
}
