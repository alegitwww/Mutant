﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;
using System.Web;

namespace MutantSelfHost.Models
{
    public class Cardapios
    {
        public int CardapioId { get; set; }
        public string CardapioNome { get; set; }
        public Boolean CardapioAtivo { get; set; }
        public string CardapioUsuario { get; set; }
        public DateTime CardapioDataAlteracao { get; set; }
    }
}
