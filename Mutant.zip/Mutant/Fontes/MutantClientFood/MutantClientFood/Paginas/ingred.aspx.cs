﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace MutantClientFood.Paginas
{
    public partial class ingred : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                atualizarListagem();
                sucessoGeralLabel.Visible = false;
                erroGeralLabel.Visible = false;
            }
        }

        public void atualizarListagem()
        {
            var wcf = new MutantSelfHostServiceReference.ServicoClient();
            ingredientesGridView.DataSource = wcf.RecuperaListaTodosIngredientes();
            ingredientesGridView.DataBind();
        }

        protected void ingredientesGridView_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            if (e.CommandName == "alterarButton")
            {
                try
                {
                    int linha = Convert.ToInt32(e.CommandArgument); //pega a linha que foi clicada
                    int id = (int)ingredientesGridView.DataKeys[linha].Value;
                    buscarPorId(id);
                }
                catch (Exception ex)
                {
                    erroGeralLabel.Text = ex.Message;
                    sucessoGeralLabel.Visible = false;
                    erroGeralLabel.Visible = true;
                    ingredientesMultiView.ActiveViewIndex = 0;
                }
            }
            if (e.CommandName == "excluirButton")
            {
                try
                {
                    int linha = Convert.ToInt32(e.CommandArgument); //pega a linha que foi clicada
                    int id = (int)ingredientesGridView.DataKeys[linha].Value;
                    excluirPorId(id);
                }
                catch (Exception ex)
                {
                    erroGeralLabel.Text = ex.Message;
                    sucessoGeralLabel.Visible = false;
                    erroGeralLabel.Visible = true;
                    ingredientesMultiView.ActiveViewIndex = 0;
                }
            }

        }

        private void excluirPorId(int id)
        {
            var wcf = new MutantSelfHostServiceReference.ServicoClient();
            wcf.ExcluirIngredientes(id);
            atualizarListagem();
            sucessoGeralLabel.Text = "Ingrediente foi excluido com sucesso !";
            erroGeralLabel.Text = null;
            sucessoGeralLabel.Visible = true;
            erroGeralLabel.Visible = false;
            ingredientesMultiView.ActiveViewIndex = 0;
        }

        private void buscarPorId(int id)
        {
            var wcf = new MutantSelfHostServiceReference.ServicoClient();
            var ingrediente = wcf.RecuperaIngredientePorId(id);

            ViewState["IngredienteId"] = ingrediente.IngredienteId;
            ingredienteAlterarTextBox.Text = ingrediente.IngredienteNome;
            ingredientesMultiView.ActiveViewIndex = 2;
        }

        protected void ingredientesGridView_RowDeleting(object sender, GridViewDeleteEventArgs e)
        {

        }

        protected void ingredientesGridView_RowUpdating(object sender, GridViewUpdateEventArgs e)
        {

        }

        protected void novoButton_Click(object sender, EventArgs e)
        {
            ingredientesMultiView.ActiveViewIndex = 1;
        }

        protected void gravarButton_Click(object sender, EventArgs e)
        {
            try
            {
                incluir();
            }
            catch (Exception ex)
            {
                erroGeralLabel.Text = ex.Message;
                sucessoGeralLabel.Visible = false;
                erroGeralLabel.Visible = true;
                ingredientesMultiView.ActiveViewIndex = 0;
            }
        }

        private void limpaCampos()
        {
            ingredienteTextBox.Text = string.Empty;
        }

        private void limpaCamposAlterar()
        {
            ingredienteAlterarTextBox.Text = string.Empty;
        }

        private void incluir()
        {
            var wcf = new MutantSelfHostServiceReference.ServicoClient();
            wcf.CadastrarIngredientes(ingredienteTextBox.Text);

            sucessoGeralLabel.Text = "Ingrediente Incluido com sucesso !";
            sucessoGeralLabel.Visible = true;
            erroGeralLabel.Visible = false;
            limpaCampos();
            atualizarListagem();
            ingredientesMultiView.ActiveViewIndex = 0;
        }

        protected void voltarButton_Click(object sender, EventArgs e)
        {
            limpaCampos();
            atualizarListagem();
            sucessoGeralLabel.Visible = false;
            erroGeralLabel.Visible = false;
            ingredientesMultiView.ActiveViewIndex = 0;
        }

        protected void voltarAlterarButton_Click(object sender, EventArgs e)
        {
            limpaCamposAlterar();
            atualizarListagem();
            sucessoGeralLabel.Visible = false;
            erroGeralLabel.Visible = false;
            ingredientesMultiView.ActiveViewIndex = 0;
        }

        protected void alterarAlterarButton_Click(object sender, EventArgs e)
        {
            try
            {
                alterar();
            }
            catch (Exception ex)
            {
                erroGeralLabel.Text = ex.Message;
                sucessoGeralLabel.Visible = false;
                erroGeralLabel.Visible = true;
                ingredientesMultiView.ActiveViewIndex = 0;
            }
        }

        private void alterar()
        {
            var wcf = new MutantSelfHostServiceReference.ServicoClient();

            int IngredienteId = (int)ViewState["IngredienteId"];
            string IngredienteNome = ingredienteAlterarTextBox.Text;
            wcf.AtualizarIngredientes(IngredienteId, IngredienteNome);
            sucessoGeralLabel.Text = "Ingrediente alterado com sucesso";
            sucessoGeralLabel.Visible = true;
            erroGeralLabel.Visible = false;
            atualizarListagem();
            ingredientesMultiView.ActiveViewIndex = 0;
        }


        protected void pesquisarButton_Click(object sender, EventArgs e)
        {
            atualizaListagemPorIngrediente();
            sucessoGeralLabel.Visible = false;
            erroGeralLabel.Visible = false;
        }

        private void atualizaListagemPorIngrediente()
        {
            var wcf = new MutantSelfHostServiceReference.ServicoClient();
            if (pesquisarTextBox.Text == string.Empty || pesquisarTextBox.Text == null)
            {
                ingredientesGridView.DataSource = wcf.RecuperaListaTodosIngredientes();
                ingredientesGridView.DataBind();
            }
            else
            {
                ingredientesGridView.DataSource = wcf.RecuperaListaTodosIngredientesPorFiltro(pesquisarTextBox.Text);
                ingredientesGridView.DataBind();
            }
        }

    }
}