﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace MutantClientFood
{
    public partial class Cardapio : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                atualizarListagem();
                sucessoGeralLabel.Visible = false;
                erroGeralLabel.Visible = false;
            }
        }

        public void atualizarListagem()
        {
            var wcf = new MutantSelfHostServiceReference.ServicoClient();
            cardapioGridView.DataSource = wcf.RecuperaListaTodosCardapios();
            cardapioGridView.DataBind();
        }

        protected void cardapioGridView_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            if (e.CommandName == "alterarButton")
            {
                try
                {
                    int linha = Convert.ToInt32(e.CommandArgument); //pega a linha que foi clicada
                    int id = (int)cardapioGridView.DataKeys[linha].Value;
                    buscarPorId(id);
                }
                catch (Exception ex)
                {
                    erroGeralLabel.Text = ex.Message;
                    sucessoGeralLabel.Visible = false;
                    erroGeralLabel.Visible = true;
                    cardapiosMultiView.ActiveViewIndex = 0;
                }
            }
            if (e.CommandName == "excluirButton")
            {
                try
                {
                    int linha = Convert.ToInt32(e.CommandArgument); //pega a linha que foi clicada
                    int id = (int)cardapioGridView.DataKeys[linha].Value;
                    excluirPorId(id);
                }
                catch (Exception ex)
                {
                    erroGeralLabel.Text = ex.Message;
                    sucessoGeralLabel.Visible = false;
                    erroGeralLabel.Visible = true;
                    cardapiosMultiView.ActiveViewIndex = 0;
                }
            }
        }

        private void excluirPorId(int id)
        {
            var wcf = new MutantSelfHostServiceReference.ServicoClient();
            wcf.ExcluirCardapio(id);
            atualizarListagem();
            sucessoGeralLabel.Text = "Cardapio foi excluido com sucesso !";
            erroGeralLabel.Text = null;
            sucessoGeralLabel.Visible = true;
            erroGeralLabel.Visible = false;
            cardapiosMultiView.ActiveViewIndex = 0;
        }

        private void buscarPorId(int id)
        {
            var wcf = new MutantSelfHostServiceReference.ServicoClient();
            var cardapio = wcf.RecuperaCardapioPorId(id);

            ViewState["CardapioId"] = cardapio.CardapioId;
            cardapioAlterarTextBox.Text = cardapio.CardapioNome;
            cardapiosMultiView.ActiveViewIndex = 2;
        }

        protected void cardapioGridView_RowDeleting(object sender, GridViewDeleteEventArgs e)
        {

        }

        protected void cardapioGridView_RowUpdating(object sender, GridViewUpdateEventArgs e)
        {

        }
        
        protected void novoButton_Click(object sender, EventArgs e)
        {
            cardapiosMultiView.ActiveViewIndex = 1;
        }

        protected void gravarButton_Click(object sender, EventArgs e)
        {
            try
            {
                incluir();
            }
            catch (Exception ex)
            {
                erroGeralLabel.Text = ex.Message;
                sucessoGeralLabel.Visible = false;
                erroGeralLabel.Visible = true;
                cardapiosMultiView.ActiveViewIndex = 0;
            }
        }

        private void limpaCampos()
        {
            cardapioTextBox.Text = string.Empty;
        }

        private void limpaCamposAlterar()
        {
            cardapioAlterarTextBox.Text = string.Empty;
        }

        private void incluir()
        {
            var wcf = new MutantSelfHostServiceReference.ServicoClient();
            wcf.CadastrarCardapio(cardapioTextBox.Text);

            sucessoGeralLabel.Text = "Cardapio Incluido com sucesso !";
            sucessoGeralLabel.Visible = true;
            erroGeralLabel.Visible = false;
            limpaCampos();
            atualizarListagem();
            cardapiosMultiView.ActiveViewIndex = 0;
        }

        protected void voltarButton_Click(object sender, EventArgs e)
        {
            limpaCampos();
            atualizarListagem();
            sucessoGeralLabel.Visible = false;
            erroGeralLabel.Visible = false;
            cardapiosMultiView.ActiveViewIndex = 0;
        }

        protected void voltarAlterarButton_Click(object sender, EventArgs e)
        {
            limpaCamposAlterar();
            atualizarListagem();
            sucessoGeralLabel.Visible = false;
            erroGeralLabel.Visible = false;
            cardapiosMultiView.ActiveViewIndex = 0;
        }

        protected void alterarAlterarButton_Click(object sender, EventArgs e)
        {
            try
            {
                alterar();
            }
            catch (Exception ex)
            {
                erroGeralLabel.Text = ex.Message;
                sucessoGeralLabel.Visible = false;
                erroGeralLabel.Visible = true;
                cardapiosMultiView.ActiveViewIndex = 0;
            }
        }

        private void alterar()
        {
            var wcf = new MutantSelfHostServiceReference.ServicoClient();

            int CardapioId = (int)ViewState["CardapioId"];
            string CardapioNome = cardapioAlterarTextBox.Text;
            wcf.AtualizarCardapio(CardapioId, CardapioNome);
            sucessoGeralLabel.Text = "Cardapio alterado com sucesso";
            sucessoGeralLabel.Visible = true;
            erroGeralLabel.Visible = false;
            atualizarListagem();
            cardapiosMultiView.ActiveViewIndex = 0;
        }
        
        protected void pesquisarButton_Click(object sender, EventArgs e)
        {
            atualizaListagemPorCardapio();
            sucessoGeralLabel.Visible = false;
            erroGeralLabel.Visible = false;
        }

        private void atualizaListagemPorCardapio()
        {
            var wcf = new MutantSelfHostServiceReference.ServicoClient();
            if (pesquisarTextBox.Text == string.Empty || pesquisarTextBox.Text == null)
            {
                cardapioGridView.DataSource = wcf.RecuperaListaTodosCardapios();
                cardapioGridView.DataBind();
            }
            else
            {
                cardapioGridView.DataSource = wcf.RecuperaListaTodosCardapiosPorFiltro(pesquisarTextBox.Text);
                cardapioGridView.DataBind();
            }
        }














    }
}