﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace MutantClientFood
{
    public partial class PrecoIngredientes : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                atualizarListagem();
                sucessoGeralLabel.Visible = false;
                erroGeralLabel.Visible = false;
            }
        }

        public void atualizarListagem()
        {
            var wcf = new MutantSelfHostServiceReference.ServicoClient();
            precosGridView.DataSource = wcf.RecuperaListaTodosPrecos();
            precosGridView.DataBind();
        }

        protected void precosGridView_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            if (e.CommandName == "alterarButton")
            {
                try
                {
                    int linha = Convert.ToInt32(e.CommandArgument); //pega a linha que foi clicada
                    int id = (int)precosGridView.DataKeys[linha].Value;
                    buscarPorId(id);
                }
                catch (Exception ex)
                {
                    erroGeralLabel.Text = ex.Message;
                    sucessoGeralLabel.Visible = false;
                    erroGeralLabel.Visible = true;
                    precosMultiView.ActiveViewIndex = 0;
                }
            }
            if (e.CommandName == "excluirButton")
            {
                try
                {
                    int linha = Convert.ToInt32(e.CommandArgument); //pega a linha que foi clicada
                    int id = (int)precosGridView.DataKeys[linha].Value;
                    excluirPorId(id);
                }
                catch (Exception ex)
                {
                    erroGeralLabel.Text = ex.Message;
                    sucessoGeralLabel.Visible = false;
                    erroGeralLabel.Visible = true;
                    precosMultiView.ActiveViewIndex = 0;
                }
            }
        }

        private void excluirPorId(int id)
        {
            var wcf = new MutantSelfHostServiceReference.ServicoClient();
            wcf.ExcluirPreco(id);
            atualizarListagem();
            sucessoGeralLabel.Text = "Preco foi excluido com sucesso !";
            erroGeralLabel.Text = null;
            sucessoGeralLabel.Visible = true;
            erroGeralLabel.Visible = false;
            precosMultiView.ActiveViewIndex = 0;
        }

        private void buscarPorId(int id)
        {
            var wcf = new MutantSelfHostServiceReference.ServicoClient();
            var preco = wcf.RecuperaPrecoPorId(id);

            ViewState["PrecoId"] = preco.PrecoId;
            ingredienteLabel.Text = preco.IngredienteNome;
            precoTextBox.Text = Convert.ToString(preco.PrecoValor);
            precosMultiView.ActiveViewIndex = 2;
        }

        protected void precosGridView_RowDeleting(object sender, GridViewDeleteEventArgs e)
        {

        }

        protected void precosGridView_RowUpdating(object sender, GridViewUpdateEventArgs e)
        {

        }
                
        protected void novoButton_Click(object sender, EventArgs e)
        {
            var wcf = new MutantSelfHostServiceReference.ServicoClient();
            IngredientesDropDownList.DataSource = wcf.RecuperaListaTodosIngredientes();
            IngredientesDropDownList.DataBind();
            IngredientesDropDownList.Items.Insert(0, string.Empty);

            precosMultiView.ActiveViewIndex = 1;
        }

        protected void gravarButton_Click(object sender, EventArgs e)
        {
            try
            {
                incluir();
            }
            catch (Exception ex)
            {
                erroGeralLabel.Text = ex.Message;
                sucessoGeralLabel.Visible = false;
                erroGeralLabel.Visible = true;
                precosMultiView.ActiveViewIndex = 0;
            }
        }

        private void limpaCampos()
        {
            precoTextBox.Text = string.Empty;
        }

        private void limpaCamposAlterar()
        {
            precoAlterarTextBox.Text = string.Empty;
        }

        private void incluir() //int PrecoIngredienteId, decimal PrecoValor
        {
            var wcf = new MutantSelfHostServiceReference.ServicoClient();
            int precoIngredienteId = Convert.ToInt32(IngredientesDropDownList.SelectedValue);
            decimal precoValor = Convert.ToDecimal(precoTextBox.Text);

            wcf.CadastrarPreco(precoIngredienteId, precoValor); 

            sucessoGeralLabel.Text = "Preço Incluido com sucesso !";
            sucessoGeralLabel.Visible = true;
            erroGeralLabel.Visible = false;
            limpaCampos();
            atualizarListagem();
            precosMultiView.ActiveViewIndex = 0;
        }

        protected void voltarButton_Click(object sender, EventArgs e)
        {
            limpaCampos();
            atualizarListagem();
            sucessoGeralLabel.Visible = false;
            erroGeralLabel.Visible = false;
            precosMultiView.ActiveViewIndex = 0;
        }

        protected void voltarAlterarButton_Click(object sender, EventArgs e)
        {
            limpaCamposAlterar();
            atualizarListagem();
            sucessoGeralLabel.Visible = false;
            erroGeralLabel.Visible = false;
            precosMultiView.ActiveViewIndex = 0;
        }

        protected void alterarAlterarButton_Click(object sender, EventArgs e)
        {
            try
            {
                alterar();
            }
            catch (Exception ex)
            {
                erroGeralLabel.Text = ex.Message;
                sucessoGeralLabel.Visible = false;
                erroGeralLabel.Visible = true;
                precosMultiView.ActiveViewIndex = 0;
            }
        }

        private void alterar()
        {
            var wcf = new MutantSelfHostServiceReference.ServicoClient();

            int PrecoId = (int)ViewState["PrecoId"];
            decimal precoValor = Convert.ToDecimal(precoAlterarTextBox.Text);
            wcf.AtualizarPreco(PrecoId, precoValor);
            sucessoGeralLabel.Text = "Preço alterado com sucesso";
            sucessoGeralLabel.Visible = true;
            erroGeralLabel.Visible = false;
            atualizarListagem();
            precosMultiView.ActiveViewIndex = 0;
        }

        protected void pesquisarButton_Click(object sender, EventArgs e)
        {
            atualizaListagemPorIngrediente();
            sucessoGeralLabel.Visible = false;
            erroGeralLabel.Visible = false;
        }

        private void atualizaListagemPorIngrediente()
        {
            var wcf = new MutantSelfHostServiceReference.ServicoClient();
            if (pesquisarTextBox.Text == string.Empty || pesquisarTextBox.Text == null)
            {
                precosGridView.DataSource = wcf.RecuperaListaTodosPrecos();
                precosGridView.DataBind();
            }
            else
            {
                precosGridView.DataSource = wcf.RecuperaListaTodosPrecosPorFiltro(pesquisarTextBox.Text);
                precosGridView.DataBind();
            }
        }

        protected void IngredientesDropDownList_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}