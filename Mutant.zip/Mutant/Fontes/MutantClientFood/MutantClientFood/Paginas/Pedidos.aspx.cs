﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace MutantClientFood.Paginas
{
    public partial class Pedidos : System.Web.UI.Page
    {
        decimal muitaCarneValorDescontado = 0;
        decimal muitoQueijoValorDescontado = 0;

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                CarregaListaCardapios();
                CarregaListaIngredientes();
            }
        }
        

        protected void CardapioNomeDropDownList_SelectedIndexChanged(object sender, EventArgs e)
        {
            IngredientesNomeLabel.Visible = true;
            IngredientesNomeDropDownList.Visible = true;
            excluirItensPedido();
            if(CardapioNomeDropDownList.SelectedValue != null && CardapioNomeDropDownList.SelectedValue != "")
            {
                var wcf = new MutantSelfHostServiceReference.ServicoClient();
                int retorno = wcf.AtualizaTransferencia(0,0);
                int retorno2 = wcf.AtualizaTransferencia2(0, 0);
                int cardapioId = Convert.ToInt32(CardapioNomeDropDownList.SelectedValue);
                incluirItensPedidosPartirCardapio(cardapioId);
                atualizarListagem();

                //Total do Pedido
                processaPedido();
            }
            else
            {
                pedidosGridView.DataSource = null;
                pedidosGridView.DataBind();
                totalPedidoLabel.Text = "0.00";
                LightLabel.Text = "0.00"; 
                muitaCarneLabel.Text = "0.00";
                muitoQueijoLabel.Text = "0.00";
                totalComDescontosLabel.Text = "0.00"; 
            }
        }



        protected void IngredientesNomeDropDownList_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (CardapioNomeDropDownList.SelectedValue != null && CardapioNomeDropDownList.SelectedValue != "")
            {
                if (IngredientesNomeDropDownList.SelectedValue != null && IngredientesNomeDropDownList.SelectedValue != "")
                {
                    int pedidoIngredienteId = Convert.ToInt32(IngredientesNomeDropDownList.SelectedValue);
                    int pedidoCardapioId = Convert.ToInt32(CardapioNomeDropDownList.SelectedValue);

                    var wcf = new MutantSelfHostServiceReference.ServicoClient();
                    var cardapio = wcf.RecuperaCardapioPorId(pedidoCardapioId);
                    string pedidoCardapioNome = cardapio.CardapioNome;

                    int pedidoQuantidade = 1;

                    incluirItensPedidosPartirIngrediente(pedidoIngredienteId, pedidoCardapioId, pedidoCardapioNome, pedidoQuantidade);
                    atualizarListagem();

                    //Total do Pedido
                    processaPedido();
                }
            }
        }



        protected void pedidosGridView_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            if (e.CommandName == "excluirButton")
            {
                try
                {
                    int linha = Convert.ToInt32(e.CommandArgument); //pega a linha que foi clicada
                    int id = (int)pedidosGridView.DataKeys[linha].Value;
                    excluirPorId(id);

                    //Total do Pedido
                    processaPedido();
                }
                catch (Exception ex)
                {
                    erroGeralLabel.Text = ex.Message;
                }
            }
        }

        protected void pedidosGridView_RowUpdating(object sender, GridViewUpdateEventArgs e)
        {

        }

        protected void pedidosGridView_RowDeleting(object sender, GridViewDeleteEventArgs e)
        {

        }

        //xxxx

        protected void InicializaFormulario()
        {


        }

        protected void CarregaListaCardapios()
        {
            var wcf = new MutantSelfHostServiceReference.ServicoClient();

            CardapioNomeDropDownList.DataSource = wcf.RecuperaListaTodosCardapios();
            CardapioNomeDropDownList.DataBind();
            CardapioNomeDropDownList.Items.Insert(0, string.Empty);
        }

        protected void CarregaListaIngredientes()
        {
            var wcf = new MutantSelfHostServiceReference.ServicoClient();

            IngredientesNomeDropDownList.DataSource = wcf.RecuperaListaTodosIngredientes();
            IngredientesNomeDropDownList.DataBind();
            IngredientesNomeDropDownList.Items.Insert(0, string.Empty);
        }

        public void atualizarListagem()
        {
            var wcf = new MutantSelfHostServiceReference.ServicoClient();
            pedidosGridView.DataSource = wcf.RecuperaTodosPedidos();
            pedidosGridView.DataBind();
        }

        private void excluirItensPedido()
        {
            var wcf = new MutantSelfHostServiceReference.ServicoClient();
            var retorno = wcf.ExcluirTodosPedidos();
        }

        private void incluirItensPedidosPartirCardapio(int cardapioId)
        {
            var wcf = new MutantSelfHostServiceReference.ServicoClient();
            var retorno = wcf.CadastrarItensPedidoPartirIngredientesCardapio(cardapioId);
        }

        private void excluirPorId(int id)
        {
            var wcf = new MutantSelfHostServiceReference.ServicoClient();
            wcf.ExcluirPedidosPorID(id);
            atualizarListagem();
        }

        private void incluirItensPedidosPartirIngrediente(int pedidoIngredienteId, int pedidoCardapioId, string pedidoCardapioNome, int pedidoQuantidade)
        {
            var wcf = new MutantSelfHostServiceReference.ServicoClient();
            wcf.CadastrarItensPedidoPartirIngredientesSelecionado(pedidoIngredienteId, pedidoCardapioId, pedidoCardapioNome, pedidoQuantidade);
        }

        private void processaPedido()
        {
            var wcf = new MutantSelfHostServiceReference.ServicoClient();
            var pedidos = wcf.RecuperaTodosPedidos();
            decimal valorTotal = 0;
            decimal valorTotalDescontos = 0;
            Boolean flagLightAlface = false;
            Boolean flagLightBacon = false;
            decimal valorPromocaoLight = 0;
            int muitaCarneQuantidadeDescontada = 0;
            int muitoQueijoQuantidadeDescontada = 0;



            foreach (var i in pedidos)
            {
                if(i.PedidoAtivo == true)
                {
                    //Acumula valor total
                    valorTotal += i.PedidoQuantidade * i.PedidoPrecoValor;

                    //Verifica ocorrencia de promoção Light
                    if(i.PedidoIngredienteNome.Contains("Alface") || i.PedidoIngredienteNome.Contains("alface") || i.PedidoIngredienteNome.Contains("ALFACE") || i.PedidoIngredienteNome.Contains("alface"))
                    {
                        flagLightAlface = true;
                    }

                    if (i.PedidoIngredienteNome.Contains("Bacon") || i.PedidoIngredienteNome.Contains("bacon") || i.PedidoIngredienteNome.Contains("BACON") || i.PedidoIngredienteNome.Contains("bacon"))
                    {
                        flagLightBacon = true;
                    }

                    //Verifica ocorrencia de promocao Muita Carne
                    if (i.PedidoIngredienteNome.Contains("Carne") || i.PedidoIngredienteNome.Contains("carne") || i.PedidoIngredienteNome.Contains("CARNE") || i.PedidoIngredienteNome.Contains("carne"))
                    {
                        if (i.PedidoQuantidade % 3 == 0)
                        {
                            muitaCarneQuantidadeDescontada = i.PedidoQuantidade / 3;
                            muitaCarneValorDescontado = muitaCarneQuantidadeDescontada * i.PedidoPrecoValor;
                            int retorno = wcf.AtualizaTransferencia(muitaCarneValorDescontado, 0);
                            
                        }
                    }

                    //Verifica ocorrencia de promocao Muito Queijo
                    if (i.PedidoIngredienteNome.Contains("Queijo") || i.PedidoIngredienteNome.Contains("queijo") || i.PedidoIngredienteNome.Contains("QUEIJO") || i.PedidoIngredienteNome.Contains("queijo"))
                    {
                        if (i.PedidoQuantidade % 3 == 0)
                        {
                            muitoQueijoQuantidadeDescontada = i.PedidoQuantidade / 3;
                            muitoQueijoValorDescontado = muitoQueijoQuantidadeDescontada * i.PedidoPrecoValor;
                            int retorno2 = wcf.AtualizaTransferencia2(muitoQueijoValorDescontado, 0);
                        }
                    }
                }
            }

            //Valor total de descontos começa valento igual ao valor total do pedido sem sem os descontos
            valorTotalDescontos = valorTotal;

            //Calcula valor da promoção Light
            if (flagLightAlface == true && flagLightBacon == false)
            {
                valorPromocaoLight = (valorTotal * 10) / 100;
            }


            //Calcula valor total com todos descontos
            valorTotalDescontos = valorTotalDescontos - (valorPromocaoLight + muitaCarneValorDescontado + muitoQueijoValorDescontado);

            totalPedidoLabel.Text = string.Format("{0:C}", valorTotal);
            LightLabel.Text = string.Format("{0:C}", valorPromocaoLight);

            //muitaCarneLabel.Text = string.Format("{0:C}", muitaCarneValorDescontado);
            //muitoQueijoLabel.Text = string.Format("{0:C}", muitoQueijoValorDescontado);
            var valor = wcf.RecuperaTransferencia();
            muitaCarneValorDescontado = valor.TransferenciaValor;
            muitaCarneLabel.Text = string.Format("{0:C}", muitaCarneValorDescontado);

            var valor2 = wcf.RecuperaTransferencia2();
            muitoQueijoValorDescontado = valor2.TransferenciaValor;
            muitoQueijoLabel.Text = string.Format("{0:C}", muitoQueijoValorDescontado);

            totalComDescontosLabel.Text = string.Format("{0:C}", valorTotalDescontos);
        }
    }
}