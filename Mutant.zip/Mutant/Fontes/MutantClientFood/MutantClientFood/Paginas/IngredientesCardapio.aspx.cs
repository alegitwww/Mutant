﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace MutantClientFood
{
    public partial class IngredientesCardapio : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                atualizarListagem();
                sucessoGeralLabel.Visible = false;
                erroGeralLabel.Visible = false;
            }
        }

        public void atualizarListagem()
        {
            var wcf = new MutantSelfHostServiceReference.ServicoClient();
            ingredientesCardapioGridView.DataSource = wcf.RecuperaListaTodosIngredientesCardapio();
            ingredientesCardapioGridView.DataBind();
        }

        protected void ingredientesCardapioGridView_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            if (e.CommandName == "excluirButton")
            {
                try
                {
                    int linha = Convert.ToInt32(e.CommandArgument); //pega a linha que foi clicada
                    int id = (int)ingredientesCardapioGridView.DataKeys[linha].Value;
                    excluirPorId(id);
                }
                catch (Exception ex)
                {
                    erroGeralLabel.Text = ex.Message;
                    sucessoGeralLabel.Visible = false;
                    erroGeralLabel.Visible = true;
                    ingredientesCardapioMultiView.ActiveViewIndex = 0;
                }
            }
        }

        private void excluirPorId(int id)
        {
            var wcf = new MutantSelfHostServiceReference.ServicoClient();
            wcf.ExcluirCardapioIngredientes(id);
            atualizarListagem();
            sucessoGeralLabel.Text = "Ingrediente do Cardapio foi excluido com sucesso !";
            erroGeralLabel.Text = null;
            sucessoGeralLabel.Visible = true;
            erroGeralLabel.Visible = false;
            ingredientesCardapioMultiView.ActiveViewIndex = 0;
        }

        protected void ingredientesCardapioGridView_RowDeleting(object sender, GridViewDeleteEventArgs e)
        {

        }

        protected void ingredientesCardapioGridView_RowUpdating(object sender, GridViewUpdateEventArgs e)
        {

        }
                
        protected void novoButton_Click(object sender, EventArgs e)
        {
            var wcf = new MutantSelfHostServiceReference.ServicoClient();

            CardapioNomeDropDownList.DataSource = wcf.RecuperaListaTodosCardapios();
            CardapioNomeDropDownList.DataBind();
            CardapioNomeDropDownList.Items.Insert(0, string.Empty);

            IngredienteNomeDropDownList.DataSource = wcf.RecuperaListaTodosIngredientes();
            IngredienteNomeDropDownList.DataBind();
            IngredienteNomeDropDownList.Items.Insert(0, string.Empty);

            ingredientesCardapioMultiView.ActiveViewIndex = 1;
        }

        protected void gravarButton_Click(object sender, EventArgs e)
        {
            try
            {
                incluir();
            }
            catch (Exception ex)
            {
                erroGeralLabel.Text = ex.Message;
                sucessoGeralLabel.Visible = false;
                erroGeralLabel.Visible = true;
                ingredientesCardapioMultiView.ActiveViewIndex = 0;
            }
        }

        private void limpaCampos()
        {
            CardapioNomeDropDownList.Items.Clear();
            IngredienteNomeDropDownList.Items.Clear();
        }


        private void incluir() //int PrecoIngredienteId, decimal PrecoValor
        {
            var wcf = new MutantSelfHostServiceReference.ServicoClient();
            int cardapioIngredientesCardapioId = Convert.ToInt32(CardapioNomeDropDownList.SelectedValue);
            int cardapioIngredientesIngredienteId = Convert.ToInt32(IngredienteNomeDropDownList.SelectedValue);

            wcf.CadastrarCardapioIngredientes(cardapioIngredientesCardapioId, cardapioIngredientesIngredienteId); 

            sucessoGeralLabel.Text = "Ingredientes do Cardápio Incluidos com sucesso !";
            sucessoGeralLabel.Visible = true;
            erroGeralLabel.Visible = false;
            limpaCampos();
            atualizarListagem();
            ingredientesCardapioMultiView.ActiveViewIndex = 0;
        }

        protected void voltarButton_Click(object sender, EventArgs e)
        {
            limpaCampos();
            atualizarListagem();
            sucessoGeralLabel.Visible = false;
            erroGeralLabel.Visible = false;
            ingredientesCardapioMultiView.ActiveViewIndex = 0;
        }

        protected void pesquisarButton_Click(object sender, EventArgs e)
        {
            atualizaListagemPorIngredientesCardapio();
            sucessoGeralLabel.Visible = false;
            erroGeralLabel.Visible = false;
        }

        private void atualizaListagemPorIngredientesCardapio()
        {
            var wcf = new MutantSelfHostServiceReference.ServicoClient();
            if (pesquisarTextBox.Text == string.Empty || pesquisarTextBox.Text == null)
            {
                ingredientesCardapioGridView.DataSource = wcf.RecuperaListaTodosIngredientesCardapio();
                ingredientesCardapioGridView.DataBind();
            }
            else
            {
                ingredientesCardapioGridView.DataSource = wcf.RecuperaListaTodosIngredientesCardapioPorFiltro(pesquisarTextBox.Text);
                ingredientesCardapioGridView.DataBind();
            }
        }





        protected void CardapioNomeDropDownList_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        protected void IngredienteNomeDropDownList_SelectedIndexChanged(object sender, EventArgs e)
        {

        }




    }
}