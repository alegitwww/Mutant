﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MutantClientFood.Models
{
    public class Ingredientes
    {
        public int IngredienteId { get; set; }
        public string IngredienteNome { get; set; }
        public Boolean IngredienteAtivo { get; set; }
        public string IngredienteUsuario { get; set; }
        public DateTime IngredienteDataAlteracao { get; set; }
    }
}